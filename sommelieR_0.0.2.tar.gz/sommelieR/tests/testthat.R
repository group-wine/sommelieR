library(testthat)
library(sommelieR)

test_check("sommelieR")
